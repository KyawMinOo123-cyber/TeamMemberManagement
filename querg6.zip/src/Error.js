const Error =()=>{
    return(
      <div className="container">
          <div className="row justify-content-center mt-3">
            <div className ="col-8">
              <h1 className="text-danger">404 - Page Not Found!</h1>
            </div>
          </div>
      </div>
    )
}
export default Error;